# AutoSkate — Android prototype (v0.2)

AutoSkate is an experimental Android overlay assistant for the skate-runner shown in the two supplied gameplay clips.

## Controls added from your clarification

- **Swipe up once:** jump.
- **Swipe up twice in quick succession:** kickflip. AutoSkate sends the second upward swipe 145 ms after the first begins, so it follows the first gesture closely.
- **Swipe down:** duck / slam down.
- **Swipe left or right:** lane change. This is retained from the original three-lane assumption; it has not been independently confirmed from your control tutorial.

## What v0.2 does

- Captures the visible game screen using Android MediaProjection.
- Shows a movable floating panel with separate **START** and **STOP** buttons.
- Displays its current status plus counters for gestures and kickflips.
- Estimates hazards and purple-moon areas in the three road lanes using lightweight colour/shape heuristics.
- Attempts a lane change if another lane looks substantially safer.
- Sends a single upward swipe for a detected blocked-lane jump, a downward swipe for a detected crossbar/duck case, and periodic double-up kickflips on apparently clear stretches.
- Keeps the user in control: tapping **STOP** prevents further automated gestures.

## Accuracy and score limitations

This is a prototype, not a validated game-playing agent. The vision system is a hand-written pixel heuristic, not a trained object detector. It can confuse the skater, road markings, scenery, vehicles, coins and barriers. It has not been calibrated on a live phone at the game's actual frame rate. The footage shows scoring prompts for tricks, but it does not prove a reliable action schedule or a route to 3,000,000 points.

**A 3,000,000-point score is not guaranteed.** Do not leave automation unattended. Test it in a short run, keep the screen visible, and stop it immediately if it sends an incorrect gesture. The app does not read the score accurately, activate perks, or verify successful landings.

## Building the Android app

The delivered download is the complete Android Studio source project in one ZIP file. It is **not an installable APK**.

To create an APK, open this project in Android Studio with Android SDK Platform 35 installed, allow Gradle to sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)** (or run `:app:assembleDebug`). Android Studio will output `app/build/outputs/apk/debug/app-debug.apk`.

I could not compile an APK in this environment because Android SDK build tools and Gradle are not installed, and external downloads are unavailable here. I have therefore not labelled a source ZIP as an APK.

## Setup on the phone after an APK has been built

1. Install the APK and open AutoSkate.
2. Tap **Allow floating overlay** and grant Android's overlay permission.
3. Tap **Enable AutoSkate gesture access**. In Android Accessibility settings, enable AutoSkate. This is required for swipe gestures.
4. Tap **Connect screen + show controls** and approve the Android screen-capture prompt.
5. Switch to the game. Move the floating panel by dragging its heading if it covers the HUD or road.
6. Tap **START** to let it take over. Tap **STOP** to stop automated gestures.

Android displays an ongoing notification while screen capture is active. Stop/close the capture service when you finish.

## Source map

- `MainActivity.kt` — permission setup and in-app instructions.
- `ScreenCaptureService.kt` — MediaProjection and frame delivery.
- `FloatingControlsService.kt` — movable START/STOP panel and live status.
- `GestureAccessibilityService.kt` — horizontal lane swipes, jump, double-up kickflip, and duck/slam gestures.
- `SkateVision.kt` — experimental three-lane pixel heuristic.
