# Build AutoSkate APK using only an Android phone

GitHub Actions builds this project in the cloud. You do not need a computer or Android Studio.

## One-time setup
1. Download the supplied `AutoSkate-v0.2-phone-cloud-build.zip` and extract it on your phone.
2. Sign in at https://github.com in your phone browser. Create a new **private** repository named `AutoSkate`.
3. In the repository, tap **Add file → Upload files** and upload `AutoSkate-Android-Prototype-v0.2.zip` from the extracted `autoskate-android` folder. Commit it to `main`.
4. Create the workflow file: **Add file → Create new file**. Name it exactly `.github/workflows/build-apk.yml` (GitHub creates the folders from the path).
5. Open `BUILD-WORKFLOW-CONTENTS.txt` from the extracted folder, copy all its contents, paste into the GitHub editor, and commit to `main`.

## Build and download
6. Open the repository's **Actions** tab and select **Build AutoSkate APK**. Choose **Run workflow** if the button appears. A push to `main` also triggers a build.
7. Wait for the run to finish successfully. Open the completed run and scroll to **Artifacts**.
8. Download `AutoSkate-debug-apk`. Extract that downloaded ZIP; it contains `app-debug.apk`.
9. Tap `app-debug.apk` to install. Android may ask you to permit your browser or file manager to install unknown apps. Only install the APK produced by your own repository's successful build.

If the build fails, open the run and inspect the first red error. Do not install an APK from an unrelated repository or third-party build service.

This creates a debug APK, not a Play Store release. AutoSkate is experimental and cannot guarantee a 3,000,000 score.
