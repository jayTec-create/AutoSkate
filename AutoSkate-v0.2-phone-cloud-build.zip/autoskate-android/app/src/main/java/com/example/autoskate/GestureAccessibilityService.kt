package com.example.autoskate

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Sends the game's touch gestures using Android's user-enabled accessibility API.
 * Controls learned from the supplied gameplay: up = jump; two quick ups = kickflip;
 * down = duck/slam. Left/right swipes change lanes.
 */
class GestureAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AutoSkateState.lastStatus = "Gesture control connected"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        AutoSkateState.enabled.set(false)
        AutoSkateState.lastStatus = "Gesture control interrupted"
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        AutoSkateState.enabled.set(false)
        return super.onUnbind(intent)
    }

    private fun swipe(fromX: Float, fromY: Float, toX: Float, toY: Float, duration: Long = 115L) {
        val path = Path().apply {
            moveTo(fromX, fromY)
            lineTo(toX, toY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        mainHandler.post { dispatchGesture(gesture, null, null) }
    }

    fun jump(screenWidth: Int, screenHeight: Int) {
        val x = screenWidth * 0.50f
        swipe(x, screenHeight * 0.79f, x, screenHeight * 0.37f)
        markAction("JUMP")
    }

    fun duck(screenWidth: Int, screenHeight: Int) {
        val x = screenWidth * 0.50f
        swipe(x, screenHeight * 0.37f, x, screenHeight * 0.79f)
        markAction("DUCK / SLAM")
    }

    fun kickflip(screenWidth: Int, screenHeight: Int) {
        val x = screenWidth * 0.50f
        // The second upward swipe follows the first immediately after it completes.
        swipe(x, screenHeight * 0.79f, x, screenHeight * 0.37f, 105L)
        mainHandler.postDelayed({
            if (AutoSkateState.enabled.get()) {
                swipe(x, screenHeight * 0.79f, x, screenHeight * 0.37f, 105L)
            }
        }, 145L)
        val now = SystemClock.elapsedRealtime()
        AutoSkateState.lastActionAt.set(now)
        AutoSkateState.lastTrickAt.set(now)
        AutoSkateState.actionsSent.incrementAndGet()
        AutoSkateState.tricksSent.incrementAndGet()
        AutoSkateState.lastStatus = "KICKFLIP · double swipe"
    }

    private fun markAction(label: String) {
        AutoSkateState.lastActionAt.set(SystemClock.elapsedRealtime())
        AutoSkateState.actionsSent.incrementAndGet()
        AutoSkateState.lastStatus = label
    }

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
            private set

        fun perform(action: String, width: Int, height: Int) {
            val service = instance ?: run {
                AutoSkateState.lastStatus = "Enable AutoSkate gesture access in Android settings"
                return
            }
            when (action) {
                "LEFT", "RIGHT" -> {
                    val from = AutoSkateState.currentLane.get().coerceIn(0, 2)
                    val to = if (action == "LEFT") from - 1 else from + 1
                    if (to in 0..2) {
                        val startX = laneX(from, width)
                        val endX = laneX(to, width)
                        val y = height * 0.70f
                        service.swipe(startX, y, endX, y, 125L)
                        AutoSkateState.currentLane.set(to)
                        AutoSkateState.lastActionAt.set(SystemClock.elapsedRealtime())
                        AutoSkateState.actionsSent.incrementAndGet()
                        AutoSkateState.lastStatus = "LANE ${if (to == 0) "LEFT" else "RIGHT"}"
                    }
                }
                "JUMP" -> service.jump(width, height)
                "KICKFLIP" -> service.kickflip(width, height)
                "DUCK" -> service.duck(width, height)
            }
        }

        private fun laneX(lane: Int, width: Int): Float = when (lane) {
            0 -> width * 0.28f
            2 -> width * 0.72f
            else -> width * 0.50f
        }
    }
}
