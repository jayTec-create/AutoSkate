package com.example.autoskate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 30, 26, 28)
        }
        val title = TextView(this).apply {
            text = "AutoSkate"
            textSize = 30f
            setPadding(0, 0, 0, 6)
        }
        val subtitle = TextView(this).apply {
            text = "Experimental automatic assistant for the supplied 3-lane skate runner"
            textSize = 15f
            setPadding(0, 0, 0, 20)
        }
        status = TextView(this).apply {
            text = "Setup required. Follow the three steps below."
            textSize = 14f
            setPadding(0, 12, 0, 18)
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(makeButton("1 · Allow floating overlay") { requestOverlay() })
        content.addView(makeButton("2 · Enable AutoSkate gesture access") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(makeButton("3 · Connect screen + show controls") { beginScreenCapture() })
        content.addView(makeButton("Stop automation") {
            AutoSkateState.enabled.set(false)
            status.text = "Automation stopped. Use the notification / Android app settings to disconnect screen capture."
            Toast.makeText(this, "AutoSkate stopped", Toast.LENGTH_SHORT).show()
        })
        content.addView(status)

        val instructions = TextView(this).apply {
            text = "GAME CONTROLS ADDED\n↑ Swipe up = jump\n↑↑ Two quick upward swipes = kickflip\n↓ Swipe down = duck / slam\n← / → Horizontal swipe = change lane\n\nHOW TO USE\n1. Open the game and start a run.\n2. Open AutoSkate and grant overlay, Accessibility and screen-capture permissions.\n3. Return to the game and tap START on the floating panel. Tap STOP at any time.\n\nACCURACY NOTE\nAutoSkate uses lightweight colour/shape detection, not a trained game model. It attempts lane changes, jumps, ducks and periodic kickflips, but can misread scenery or timing. The 3,000,000-point goal cannot be guaranteed. Keep the run visible and supervise it."
            textSize = 14f
            setLineSpacing(5f, 1.0f)
            setPadding(0, 18, 0, 0)
        }
        content.addView(instructions)

        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (GestureAccessibilityService.instance != null)
                "Gesture access connected. Continue with screen capture."
            else "Check Android Accessibility settings and enable AutoSkate."
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 7 }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingControlsService::class.java))
            status.text = "Floating controls enabled."
        } else {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    private fun beginScreenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow the floating overlay first", Toast.LENGTH_LONG).show()
            requestOverlay()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Android result callback used to avoid extra ActivityX dependencies")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            startService(Intent(this, FloatingControlsService::class.java))
            status.text = "Screen connected. Switch to the game and tap START on the floating panel."
        } else if (requestCode == requestCapture) {
            status.text = "Screen capture permission was not granted."
        }
    }
}
