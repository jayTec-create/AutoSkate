package com.example.autoskate

import android.graphics.Bitmap
import android.graphics.Color
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative colour/shape heuristics tuned against the supplied portrait gameplay clips.
 * This is not machine learning: visually similar scenery can still be misclassified.
 */
object SkateVision {
    private data class LaneRead(
        val hazard: Int,
        val moons: Int,
        val redWhiteBar: Int,
        val orangeBarrier: Int,
        val blueObject: Int,
        val brightObject: Int
    )

    fun decide(bitmap: Bitmap): VisionDecision {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 100 || h < 100) return VisionDecision(null, "Screen image too small")

        val current = AutoSkateState.currentLane.get().coerceIn(0, 2)
        val reads = (0..2).map { readLane(bitmap, it, current) }
        val here = reads[current]
        val alternatives = (0..2).filter { it != current }
        val bestLane = alternatives.minByOrNull { laneCost(reads[it]) }
        val safestCost = bestLane?.let { laneCost(reads[it]) } ?: Int.MAX_VALUE
        val currentCost = laneCost(here)
        val now = SystemClock.elapsedRealtime()
        val lastAction = AutoSkateState.lastActionAt.get()
        val lastTrick = AutoSkateState.lastTrickAt.get()

        // Change lane before attempting a trick when a clearly safer route is available.
        val shouldChangeLane = here.hazard > 115 && bestLane != null &&
            safestCost < (currentCost * 0.72f).toInt() && safestCost < 150

        val action = when {
            shouldChangeLane && now - lastAction > 760L -> if (bestLane!! < current) "LEFT" else "RIGHT"
            // If blocked and no safer lane exists, use a vertical evasive move.
            here.hazard > 240 && now - lastAction > 760L -> when {
                here.redWhiteBar > 25 -> "DUCK"
                here.orangeBarrier > 9 -> "JUMP"
                here.blueObject > 10 -> "JUMP"
                here.brightObject > 35 -> "JUMP"
                else -> null
            }
            // Use tricks only when the current lane and the near-forward space look clear.
            here.hazard < 95 && now - lastTrick > 2450L && now - lastAction > 850L -> "KICKFLIP"
            else -> null
        }

        val status = "L ${reads[0].hazard} · C ${reads[1].hazard} · R ${reads[2].hazard}" +
            " | moons ${reads[current].moons} | " + when (action) {
                "LEFT" -> "safer lane left"
                "RIGHT" -> "safer lane right"
                "JUMP" -> "obstacle — jump"
                "DUCK" -> "bar — duck/slam"
                "KICKFLIP" -> "clear stretch — kickflip"
                else -> "scanning"
            }
        return VisionDecision(action, status)
    }

    private fun readLane(bitmap: Bitmap, lane: Int, currentLane: Int): LaneRead {
        val w = bitmap.width
        val h = bitmap.height
        var anomalies = 0
        var moons = 0
        var redWhite = 0
        var orange = 0
        var blue = 0
        var bright = 0
        var samples = 0
        var allCandidatePixels = 0
        val stepX = max(2, w / 300)
        val stepY = max(2, h / 430)
        val yStart = (h * 0.47f).toInt()
        val yEnd = (h * 0.72f).toInt()
        val road = estimateRoad(bitmap, lane, w, h)
        val playerCenterX = laneCenter(currentLane, w, 1f)

        var y = yStart
        while (y < yEnd) {
            val depth = (y - yStart).toFloat() / (yEnd - yStart).coerceAtLeast(1)
            val cx = laneCenter(lane, w, depth)
            val half = (w * (0.060f + 0.035f * depth)).toInt().coerceAtLeast(4)
            var x = max(0, cx - half)
            val xEnd = min(w - 1, cx + half)
            while (x <= xEnd) {
                allCandidatePixels++
                // The skater occupies the lower centre of the active lane; exclude that
                // foreground sprite so it is not mistaken for an incoming obstacle.
                if (lane == currentLane && y > h * 0.56f && abs(x - playerCenterX) < w * 0.09f) {
                    x += stepX
                    continue
                }
                val c = bitmap.getPixel(x, y)
                samples++
                if (isMoonPurple(c)) moons++
                else {
                    val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                    if (isRedWhiteBarrierPixel(c)) redWhite++
                    if (isOrangeBarrierPixel(c)) orange++
                    if (isBlueObjectPixel(c)) blue++
                    if (max(r, max(g, b)) > 180 && abs(r - g) + abs(g - b) > 80) bright++
                    if (isNonRoad(c, road)) {
                        // Stronger weighting closer to the player makes the action timely.
                        val weight = 1 + (depth * 2f).toInt()
                        anomalies += weight
                    }
                }
                x += stepX
            }
            y += stepY
        }
        val norm = if (allCandidatePixels == 0) 1f else 9500f / allCandidatePixels
        return LaneRead(
            hazard = (anomalies * norm).toInt(),
            moons = (moons * norm).toInt(),
            redWhiteBar = (redWhite * norm).toInt(),
            orangeBarrier = (orange * norm).toInt(),
            blueObject = (blue * norm).toInt(),
            brightObject = (bright * norm).toInt()
        )
    }

    private fun laneCost(read: LaneRead): Int = read.hazard - min(read.moons, 50) / 5

    private fun laneCenter(lane: Int, width: Int, depth: Float): Int {
        // The three lanes converge toward the horizon and spread toward the player.
        val offset = (width * (0.105f + 0.18f * depth.coerceIn(0f, 1f))).toInt()
        return when (lane) {
            0 -> width / 2 - offset
            2 -> width / 2 + offset
            else -> width / 2
        }
    }

    private fun estimateRoad(bitmap: Bitmap, lane: Int, width: Int, height: Int): Int {
        val cx = laneCenter(lane, width, 1f)
        val y = (height * 0.84f).toInt().coerceIn(0, height - 1)
        val values = ArrayList<Int>(5)
        for (dx in listOf(-30, -18, 0, 18, 30)) {
            val x = (cx + dx * width / 400).coerceIn(0, width - 1)
            values.add(bitmap.getPixel(x, y))
        }
        val rs = values.map { Color.red(it) }.sorted()
        val gs = values.map { Color.green(it) }.sorted()
        val bs = values.map { Color.blue(it) }.sorted()
        val mid = values.size / 2
        return Color.rgb(rs[mid], gs[mid], bs[mid])
    }

    private fun isMoonPurple(color: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return r > 78 && b > 100 && b > g * 1.13 && r > g * 1.10 && abs(r - b) < 145
    }

    private fun isRedWhiteBarrierPixel(color: Int): Boolean {
        // Count the red stripes only; the white core of collectible moons also looks white.
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return r > 145 && r > g * 1.30 && r > b * 1.20 && g < 140
    }

    private fun isBlueObjectPixel(color: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return b > 80 && b > r * 1.20 && g > 45 && b > g * 0.82 && !isMoonPurple(color)
    }

    private fun isOrangeBarrierPixel(color: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return r > 175 && g in 65..190 && b < 115 && r > g * 1.30
    }

    private fun isNonRoad(color: Int, road: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        val rr = Color.red(road); val rg = Color.green(road); val rb = Color.blue(road)
        val difference = abs(r - rr) + abs(g - rg) + abs(b - rb)
        val saturation = max(r, max(g, b)) - min(r, min(g, b))
        val brightness = max(r, max(g, b))
        return (difference > 92 && brightness > 58 && saturation > 24) ||
            (brightness > 210 && saturation > 45)
    }
}
