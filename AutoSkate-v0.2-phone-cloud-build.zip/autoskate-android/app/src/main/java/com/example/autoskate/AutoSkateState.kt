package com.example.autoskate

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

object AutoSkateState {
    val enabled = AtomicBoolean(false)
    val currentLane = AtomicInteger(1) // 0 left, 1 middle, 2 right
    val actionsSent = AtomicInteger(0)
    val tricksSent = AtomicInteger(0)
    val lastActionAt = AtomicLong(0L)
    val lastTrickAt = AtomicLong(0L)
    val lastAnalysisAt = AtomicLong(0L)
    @Volatile var lastStatus: String = "Waiting for screen capture"

    fun resetRun() {
        enabled.set(false)
        currentLane.set(1)
        actionsSent.set(0)
        tricksSent.set(0)
        lastActionAt.set(0L)
        lastTrickAt.set(0L)
        lastAnalysisAt.set(0L)
        lastStatus = "Ready — press START"
    }
}

data class VisionDecision(val action: String?, val status: String)
