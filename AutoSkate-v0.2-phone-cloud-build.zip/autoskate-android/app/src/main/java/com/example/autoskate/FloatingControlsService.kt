package com.example.autoskate

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingControlsService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var statusText: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            statusText?.text = if (AutoSkateState.enabled.get()) {
                "AUTO ON · ${AutoSkateState.lastStatus}\nActions ${AutoSkateState.actionsSent.get()} · Tricks ${AutoSkateState.tricksSent.get()}"
            } else "AUTO OFF · ${AutoSkateState.lastStatus}"
            handler.postDelayed(this, 450L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
        handler.post(refresh)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(Color.argb(238, 30, 23, 43))
        }
        val heading = TextView(this).apply {
            text = "AUTOSKATE · LIVE CONTROL"
            setTextColor(Color.WHITE)
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(2, 2, 2, 3)
        }
        statusText = TextView(this).apply {
            text = "AUTO OFF"
            setTextColor(Color.WHITE)
            textSize = 10.5f
            setPadding(2, 3, 2, 6)
            maxWidth = 260
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply {
            text = "START"
            textSize = 10f
            minWidth = 0
            setPadding(5, 0, 5, 0)
            setOnClickListener {
                if (GestureAccessibilityService.instance == null) {
                    AutoSkateState.lastStatus = "Enable AutoSkate in Accessibility settings first"
                } else {
                    AutoSkateState.enabled.set(true)
                    AutoSkateState.lastStatus = "Watching road — automation active"
                    AutoSkateState.lastActionAt.set(android.os.SystemClock.elapsedRealtime())
                    AutoSkateState.lastTrickAt.set(android.os.SystemClock.elapsedRealtime())
                }
            }
        }
        val stop = Button(this).apply {
            text = "STOP"
            textSize = 10f
            minWidth = 0
            setPadding(5, 0, 5, 0)
            setOnClickListener {
                AutoSkateState.enabled.set(false)
                AutoSkateState.lastStatus = "Stopped by user"
            }
        }
        val close = Button(this).apply {
            text = "×"
            textSize = 10f
            minWidth = 0
            setPadding(5, 0, 5, 0)
            setOnClickListener {
                AutoSkateState.enabled.set(false)
                stopSelf()
            }
        }
        row.addView(start)
        row.addView(stop)
        row.addView(close)
        box.addView(heading)
        box.addView(statusText)
        box.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 105
        }
        // Drag the heading to move the panel clear of the game HUD / road.
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        heading.setOnTouchListener { _, event ->
            val p = overlayParams ?: params
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = p.x
                    startY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (startX + downX - event.rawX).toInt()
                    p.y = (startY + event.rawY - downY).toInt()
                    runCatching { windowManager.updateViewLayout(box, p) }
                    true
                }
                else -> false
            }
        }
        overlayParams = params
        panel = box
        windowManager.addView(box, params)
    }

    override fun onDestroy() {
        AutoSkateState.enabled.set(false)
        handler.removeCallbacksAndMessages(null)
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        overlayParams = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
